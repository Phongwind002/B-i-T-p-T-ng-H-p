import numpy as np

np.random.randn(3, 3)