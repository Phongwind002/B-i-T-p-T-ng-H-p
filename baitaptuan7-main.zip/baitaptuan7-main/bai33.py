import numpy as np

u = np.random.uniform(size=4)
print(u)